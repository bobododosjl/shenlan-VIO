#! /bin/bash

echo start vio_data_simulation

source devel/setup.bash

rosrun vio_data_simulation vio_data_simulation_node 
