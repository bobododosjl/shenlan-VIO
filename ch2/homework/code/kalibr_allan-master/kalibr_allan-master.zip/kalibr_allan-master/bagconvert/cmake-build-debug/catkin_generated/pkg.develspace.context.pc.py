# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/sjl/GNC/SLAM/总结/从零手写VIO/第二章/homework/kalibr_allan-master/bagconvert/src;/usr/include".split(';') if "/home/sjl/GNC/SLAM/总结/从零手写VIO/第二章/homework/kalibr_allan-master/bagconvert/src;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;nav_msgs;std_msgs;sensor_msgs;nav_msgs;rosbag".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "/usr/lib/x86_64-linux-gnu/libboost_system.so;/usr/lib/x86_64-linux-gnu/libboost_filesystem.so;/usr/lib/x86_64-linux-gnu/libboost_thread.so;-lpthread;/usr/lib/x86_64-linux-gnu/libboost_date_time.so;/usr/lib/x86_64-linux-gnu/libboost_chrono.so;/usr/lib/x86_64-linux-gnu/libboost_atomic.so".split(';') if "/usr/lib/x86_64-linux-gnu/libboost_system.so;/usr/lib/x86_64-linux-gnu/libboost_filesystem.so;/usr/lib/x86_64-linux-gnu/libboost_thread.so;-lpthread;/usr/lib/x86_64-linux-gnu/libboost_date_time.so;/usr/lib/x86_64-linux-gnu/libboost_chrono.so;/usr/lib/x86_64-linux-gnu/libboost_atomic.so" != "" else []
PROJECT_NAME = "bagconvert"
PROJECT_SPACE_DIR = "/home/sjl/GNC/SLAM/总结/从零手写VIO/第二章/homework/kalibr_allan-master/bagconvert/cmake-build-debug/devel"
PROJECT_VERSION = "1.0.0"
