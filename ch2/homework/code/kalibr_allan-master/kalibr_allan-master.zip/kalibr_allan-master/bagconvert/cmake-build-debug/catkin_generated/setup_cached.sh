#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/sjl/GNC/SLAM/总结/从零手写VIO/第二章/homework/kalibr_allan-master/bagconvert/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/sjl/GNC/SLAM/总结/从零手写VIO/第二章/homework/kalibr_allan-master/bagconvert/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/sjl/GNC/SLAM/总结/从零手写VIO/第二章/homework/kalibr_allan-master/bagconvert:$ROS_PACKAGE_PATH"