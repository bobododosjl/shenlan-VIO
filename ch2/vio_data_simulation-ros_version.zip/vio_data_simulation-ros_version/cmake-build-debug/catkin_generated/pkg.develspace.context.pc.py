# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "vio_data_simulation"
PROJECT_SPACE_DIR = "/home/sjl/GNC/SLAM/summary/从零手写VIO/第二章/homework/course2_hw_new/vio_data_simulation-ros_version/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
